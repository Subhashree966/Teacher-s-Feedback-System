/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package teacherfeedbacksystem;

/**
 *
 * @author USER
 */
public class TEACHERFEEDBACKSYSTEM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Homepage hp=new Homepage();
        hp.show();
    }
    
}
