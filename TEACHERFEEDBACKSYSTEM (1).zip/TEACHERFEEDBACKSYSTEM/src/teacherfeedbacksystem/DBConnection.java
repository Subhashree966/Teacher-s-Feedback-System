/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package teacherfeedbacksystem;
import java.sql.*;
/**
 *
 * @author USER
 */
public class DBConnection {
    static final String db_url="jdbc:mysql://localhost:3306/teacherfeedbacksystem";
    static final String User="root";
    static final String pass="@v230504i0112";
 public static Connection connectDB(){
      Connection con=null;
     try{
         //registering the driver..
         Class.forName("com.mysql.cj.jdbc.Driver");
                 
         con=DriverManager.getConnection(db_url,User,pass);
         return con;
     }
     catch(Exception e){
         System.out.println("There were errors while connecting  to database");
       return null;
     }
 }
}
